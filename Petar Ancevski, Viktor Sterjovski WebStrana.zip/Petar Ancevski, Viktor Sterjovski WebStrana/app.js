const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
const path = require('path');

// Load environment variables from .env file
require('dotenv').config();

mongoose.connect('mongodb://0.0.0.0/book')
const conn = mongoose.connection;

// Serve static files from the "public" folder
app.use(express.static('public'));

// Set EJS as the templating engine
app.set('view engine', 'ejs');

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware
app.use(express.urlencoded({ extended: false }));

// Define the Book schema and model
const Schema = mongoose.Schema;

const bookSchema = new Schema({
    title: { type: String, required: true },
    author: { type: String, required: true },
    genre: { type: String, required: true },
    year: { type: Number, required: true },
});

const Book = mongoose.model('Book', bookSchema);

// User Schema for Registration
const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    date: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

// Routes here
app.get('/', (req, res) => {
    res.render('welcome');
});

// Home route for book listing (now at '/books')
app.get('/books', (req, res) => {
    // Fetch books from MongoDB using Mongoose
    Book.find()
        .then(books => {
            res.render('index', { books });
        })
        .catch(err => console.log(err));
});

// Add book route
app.get('/add', (req, res) => {
    res.render('addBook');
});

app.post('/add', (req, res) => {
    const { title, author, genre, year } = req.body;
    const newBook = new Book({
        title,
        author,
        genre,
        year,
    });

    newBook.save()
        .then(() => res.redirect('/books'))
        .catch(err => console.log(err));
});

// View book details
app.get('/books/:id', (req, res) => {
    Book.findById(req.params.id)
        .then(book => {
            if (!book) {
                return res.send('Book not found');
            }
            res.render('bookDetails', { book });
        })
        .catch(err => console.log(err));
});
// Server setup
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
